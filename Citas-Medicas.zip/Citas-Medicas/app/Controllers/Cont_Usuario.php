<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\mod_Usuario;

class Cont_Usuario extends Controller{

  public function index(){
    $pac = new mod_Usuario();
    $data['pacientes']=$pac->findAll();
    return view('inicio',$data);
  }

  public function registrarCita(){
    return view('agregar');
  }

  public function insertar(){
    $pac = new mod_Usuario();

    $dato=[
      'usuTipoDocumento' => $_POST['usuTipoDocumento'],
      'usuDocumento' => $_POST['usuDocumento'],
      'usuNombre' => $_POST['usuNombre'],
      'usuApellido' => $_POST['usuApellido'],
      'usuTelefono' => $_POST['usuTelefono'],
      'usuDireccion' => $_POST['usuDireccion'],
      'usuServicio' => $_POST['usuServicio'],
      'usuDoctor' => $_POST['usuDoctor']
    ];
    $pac->insert($dato);
    return redirect()->to(base_url());
  }

  public function eliminar($usuId=null){
    $pac = new mod_Usuario();
    $pac->delete($usuId);
    return redirect()->to(base_url());
  }

  public function editar($usuId=null){
    $pac = new mod_Usuario();
    $registro['paciente']=$pac->find($usuId);
    return view('actualizar',$registro);
  }

  public function actuallizar(){
    $pac = new mod_Usuario();
    $usuId = $_POST['usuId'];

    $dato=[
      'usuTipoDocumento' => $_POST['usuTipoDocumento'],
      'usuDocumento' => $_POST['usuDocumento'],
      'usuNombre' => $_POST['usuNombre'],
      'usuApellido' => $_POST['usuApellido'],
      'usuTelefono' => $_POST['usuTelefono'],
      'usuDireccion' => $_POST['usuDireccion'],
      'usuServicio' => $_POST['usuServicio'],
      'usuDoctor' => $_POST['usuDoctor']
    ];
    $pac->update($usuId,$dato);
    return redirect()->to(base_url());
  }
}