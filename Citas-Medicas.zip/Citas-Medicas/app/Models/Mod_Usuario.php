<?php 
namespace App\Models;

use CodeIgniter\Model;

class Mod_Usuario extends Model{
  protected $table ='usuario';
  protected $primaryKey = 'usuId';
  protected $allowedFields=['usuTipoDocumento','usuDocumento','usuNombre','usuApellido','usuTelefono','usuDireccion','usuServicio','usuDoctor'];
}
