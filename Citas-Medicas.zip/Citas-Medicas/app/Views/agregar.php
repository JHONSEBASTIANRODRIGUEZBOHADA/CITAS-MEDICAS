<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Asignar Cita</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
</head>

<body>
  <style>
    body {
      background-color: royalblue;
    }
  </style>
  <section class="hero is-primary">
        <div class="hero-body">
            <p class="title">HOSPITAL FAMISANAR</p>
            <p class="subtitle">Agenda tu cita aqui</p>
        </div>
    </section><br>
  <div class="container">
    <form action="insertar" method="POST">
      <div class="form-row">
        <div class="form-group col-md-4">
          <label>Tipo Documento</label>
          <select id="usuTipoDocumento" name="usuTipoDocumento" class="form-control">
            <option selected>Elija...</option>
            <option>C.C</option>
            <option>T.I</option>
          </select>
        </div>
        <div class="form-group col-md-6">
          <label>Documento</label>
          <input type="number" class="form-control" id="usuDocumento" name="usuDocumento">
        </div>
        <div class="form-group col-md-6">
          <label>Nombre</label>
          <input type="text" class="form-control" id="usuNombre" name="usuNombre">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group col-md-6">
          <label>Apellido</label>
          <input type="text" class="form-control" id="usuApellido" name="usuApellido">
        </div>
        <div class="form-group col-md-6">
          <label>Telefono</label>
          <input type="number" class="form-control" id="usuTelefono" name="usuTelefono">
        </div>
        <div class="form-group col-md-6">
          <label>Direccion</label>
          <input type="text" class="form-control" id="usuDireccion" name="usuDireccion">
        </div>
        <div class="form-group col-md-4">
          <label>Servicio</label>
          <select id="usuServicio" name="usuServicio" class="form-control">
            <option selected>Elija...</option>
            <option>Consulta General</option>
            <option>Control De Embarazo</option>
            <option>Tratamiento Especializado</option>
          </select>
        </div>
        <div class="form-group col-md-4">
          <label>Doctor</label>
          <select id="usuDoctor" name="usuDoctor" class="form-control">
            <option selected>Elija...</option>
            <option>George Zapata</option>
            <option>Omar Rodriguez</option>
            <option>Jose Perez</option>
          </select>
        </div>
      </div>
      <button type="submit" class="btn btn-warning">Registrar</button>
      <button type="submit" class="btn btn-danger">Salir</button>
  </div>

  </form>
  </div>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>

</html>