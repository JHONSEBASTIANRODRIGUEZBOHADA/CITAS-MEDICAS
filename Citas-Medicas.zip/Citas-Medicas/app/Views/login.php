<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style>
        body {
            background-color: aquamarine;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            text-align: center;
        }

        button,
        a {
            background-color: yellowgreen;
            border: none;
            color: black;
            padding: -6px 2px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 10px 2px;
            cursor: pointer;
            border-radius: 5px;
        }
    </style>
    <title>Iniciar Sesion</title>
</head>

<body>

    <div class="container">
        <h1>Iniciar Sesion</h1>

        <form method="post">
            <table>
                <tr>
                    <td><label> Usuario: </label></td>
                    <td><input type="text" name="usuLogin"></td>
                </tr>
                <tr>
                    <td><label> Contraseña: </label></td>
                    <td><input type="password" name="usuPassword"></td>
                </tr>
            </table><br>
            <button class="button"><a href="home.php">Iniciar</a></button>
            <button class="button"><a href="registro.php">Registrarse</a></button>
        </form>
    </div>
</body>

</html>